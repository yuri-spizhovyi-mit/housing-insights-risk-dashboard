Helper scripts (seed, bucket create, etc.).
