#!/usr/bin/env bash
set -euo pipefail
echo "Seeding demo data for: $@ (placeholder)"
