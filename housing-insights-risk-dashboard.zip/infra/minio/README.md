Bucket policies and bootstrap notes.
