Place .sql files to bootstrap schemas.
