# Modeling

Prophet/LightGBM, RF/LogReg, Isolation Forest, DistilBERT.
