# Tooling

Pre-commit config and CI workflows.
