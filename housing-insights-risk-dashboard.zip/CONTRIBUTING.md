# Contributing

- Use feature branches: `feat/...`, `fix/...`.
- Run linters/tests before PRs: `make test`.
- Keep README files up to date when structure changes.
