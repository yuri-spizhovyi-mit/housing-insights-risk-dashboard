# Stop and remove the MinIO container
# Usage: .\stop-minio.ps1

Write-Host "⏹ Stopping MinIO..."

# Stop container if running
docker stop minio 2>$null

# Remove container if exists
docker rm minio 2>$null

Write-Host "✅ MinIO container stopped and removed."
