# 🖥️ UI — Frontend Interface

This folder contains the React-based user interface for the Housing Insights + Risk Dashboard.
It visualizes housing data, forecast trends, and regional risk scores with charts, maps, and interactive components.
