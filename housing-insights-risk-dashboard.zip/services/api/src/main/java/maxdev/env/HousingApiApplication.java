package maxdev.env;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HousingApiApplication {
	public static void main(String[] args) {
		SpringApplication.run(HousingApiApplication.class, args);
	}
}
