# Start MinIO in Docker on Windows
# Usage: right-click → "Run with PowerShell" OR run: .\start-minio.ps1

# Stop and remove any old MinIO container if it exists
docker rm -f minio 2>$null

# Make sure data folder exists
if (!(Test-Path ".minio-data")) {
    New-Item -ItemType Directory -Path ".minio-data" | Out-Null
}

# Run MinIO
docker run -d --name minio `
  -p 9000:9000 -p 9001:9001 `
  -e MINIO_ROOT_USER=minioadmin `
  -e MINIO_ROOT_PASSWORD=minioadmin `
  -v "${PWD}\.minio-data:/data" `
  quay.io/minio/minio server /data --console-address ":9001"

Write-Host "✅ MinIO is starting..."
Write-Host "Console: http://localhost:9001 (login with minioadmin / minioadmin)"
Write-Host "API:     http://localhost:9000"
