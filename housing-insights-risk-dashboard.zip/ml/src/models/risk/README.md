Random Forest / Logistic Regression risk classifier.
