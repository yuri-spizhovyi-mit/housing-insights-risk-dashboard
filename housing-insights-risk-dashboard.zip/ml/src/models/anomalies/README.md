Isolation Forest anomaly detection.
