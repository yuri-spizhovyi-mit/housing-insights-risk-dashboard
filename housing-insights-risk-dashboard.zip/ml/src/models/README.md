Model code for forecasting, risk, anomalies.
