PDF report generator service/templates.
