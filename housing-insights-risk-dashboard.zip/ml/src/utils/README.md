Shared helpers.
