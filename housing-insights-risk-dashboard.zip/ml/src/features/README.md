Feature engineering utilities.
