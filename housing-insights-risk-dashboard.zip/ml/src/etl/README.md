ETL jobs to Postgres and MinIO.
