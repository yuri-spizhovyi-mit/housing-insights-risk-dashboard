Exported sample PDFs.
