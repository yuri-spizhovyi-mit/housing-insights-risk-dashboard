Report templates and example outputs.
