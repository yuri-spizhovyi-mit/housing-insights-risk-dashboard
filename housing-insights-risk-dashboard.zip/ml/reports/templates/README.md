Jinja/HTML/LaTeX templates.
