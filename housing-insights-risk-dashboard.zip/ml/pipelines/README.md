Pipeline entry points (daily/weekly jobs).
