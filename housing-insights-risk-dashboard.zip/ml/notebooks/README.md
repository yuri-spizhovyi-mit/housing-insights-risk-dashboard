Exploratory notebooks (EDA, experiments).
