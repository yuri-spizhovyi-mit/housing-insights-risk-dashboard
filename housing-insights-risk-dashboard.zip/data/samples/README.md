Tiny CSV/JSON for tests & demo seeding.
