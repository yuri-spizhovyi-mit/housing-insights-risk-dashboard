# Data

Use MinIO/S3 for large data. Keep tiny samples here.
