package hird.dto;

public record LoginUserDto(
    String email,
    String password
) {}


