package hird.dto;

public record RiskGaugeIndicator(
   String name,
   String status
) {}
