package hird;

 import org.springframework.boot.test.context.SpringBootTest;
 import org.junit.jupiter.api.Test;

 @SpringBootTest
 class ApplicationTests {
     @Test
     void contextLoads() {
     }
 }
